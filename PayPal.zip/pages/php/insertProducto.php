<?php
   
   $rootPath = "";
   include('../conexionbdd.php');
   $nombre;
   $precio;
   $cantidad;
   $nombreImagen;

   if(isset($_POST['btnguardar']))
   {

      $GLOBALS["nombre"] = $_POST['nombre'];
      $GLOBALS["precio"] = $_POST['precio'];
     
      $imagen = $_FILES['imagen']['name'];
      $tmp_name = $_FILES["imagen"]["tmp_name"];
      $imgSize = $_FILES['imagen']['size'];

      $repositorio = '../../img/';
    
      $extension = strtolower(pathinfo($imagen,PATHINFO_EXTENSION));
      $valid_extensions = array('jpeg', 'jpg', 'png', 'gif');
      $GLOBALS["nombreImagen"] = rand(1000,1000000).".".$extension;
       
      if(in_array($extension, $valid_extensions)){   
          // Check file size '5MB'
          if($imgSize < 5000000)    {
            move_uploaded_file($tmp_name,$repositorio.$nombreImagen);
          }
          else{
           $errMSG = "Solo se admite 5MB";
          }
      } else{
       $errMSG = "Solo se admite JPG, JPEG, PNG & GIF ";  
      }
   
      if(!isset($errMSG))
      {
            $cat=1;
            $stmt = $con->prepare('INSERT INTO productos(nombre,precio,imagen, categoriaProductoId)VALUES(:nom,:pre,:img,:cat)');
            $stmt->bindParam(':nom',$GLOBALS["nombre"]);
            $stmt->bindParam(':pre',$GLOBALS["precio"]);
            $stmt->bindParam(':img',$GLOBALS["nombreImagen"]);
            $stmt->bindParam(':cat',$GLOBALS["cat"]);
            
            if($stmt->execute()){
               header("Location:../../list-producto.php");
            }else{
               $errMSG = "Error al guardar los datos";
            }
      }

   }else{
      echo "error";
   }

?>
